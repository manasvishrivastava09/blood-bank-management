from django.apps import AppConfig


class BloodbankConfig(AppConfig):
    name = 'bloodbank'
